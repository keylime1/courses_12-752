def f(x, y, z):
    assert(x + y + z < 20)
    prev = None
    total = 10 ** x
    for w in range(x, y, z):
        if (prev != None):
            assert(w - prev == x)
        prev = w 
        total += w
    return (total == 1018) and (y % x == 1)



# nth something

def nthSquareNumber(n):
    found = 0
    guess = 0
    while found <= n: 
        guess += 1 
        if isSquare(guess):
            found += 1
    return guess 


def ct1(s, t):
    for c in s:
        if (c.upper() not in "NO!!!"):
            i = t.find(c)
            print(i, d[i], t[i])
ct1("net", "two")


def wordWrap(text, width):
    result = ''''''
    while(word != ""):
        currentString = word[:width] + '''\n'''
        result += currentString
        word = wprd[width:]
    seenSoace = False
    newResult = ''''''
    for subWord in result.splitlines():
        newResult += subWord.strip() + '''\n'''
    newResult = newResult.rstrip()
    newResult = newResult.replace(" ", "-")
    return newResult

# sorting 
# bigO
# merge sort!!!

# 2d list 
import copy

a = [[15, 112], ["is", "fun"]]
b = a 
c = copy.copy(a)
d = copy.deepcopy(a)

print(a is b, a is c, a is d, c is d)
print(a == b, a == c, a == d, c == d)

a[0] = ["nothing", "else"]
b[1] = [42, "foo"]
c[0] += [15, 112]
d[1] += ["Jordan", ":)"]

c += ["koz", "mjs"]

print(a, b, c, d)


def isThisEvenWordSearch(board, word)：
    for col in range(len(board[0])):
        if not boardSatisfiesTheProperty(board, word, col):
            return False
    return True

def boardSatisfiesTheProperty(board, targetWord, col):
    boardWord = ""
    for row in range(len(board)):
        if boardWord != "" and board[row][col] == boardWord[-1]:
            continue
        letter = board[row][col]
        if letter == targetWord[len(boardWord)]:
            boardWord += letter
        elif letter == boardWord[-1]:
            continue
        else:
            boardWord = ""
    retuen boardWord = targetWord

# efficiency
# selection sort  n*(n+1)/2
# bubble sort n2
# merge sort 



# midterm func dec

def callCounter(f):
    def g(*args):
        if g.__name__ not in COUNTS:
            COUNTS[g.__name__] = 0
        COUNTS[g.__name__] += 1
        return(f(*args))
    return g

@callCounter
def f(x):
    return 42

# word ladder
def diff:
    diff = 0 
    for i in range(max(len(w1), len(w2))):


def solveWordLadder(wordList, word1, word2):
    def solve(word, remaining):
        if difference(word, word2) <= 1:
            return [word, word2]
        else: 
            minLadder = None
            for i in range(len(remaining)):
                nextWord = remaining[i]
                if difference(word, nextWord) <= 1:
                    newRemaining = remaining[:i] + remaining[i+1:1]
                    newLadder = solve(nextWord, newRemaining)

                    if newLadder != None:
                        newLadder = [word] + newLadder
                        if minLadder == None or len(newLadder) < len(minLadder):
                            minLadder = newLadder
            return minLadder


    wordList.remove(word1)
    return solve(word1, wordList)


import os
# midterm contains copies
def containsCopy(path):
    seenContents
    def solve(path):
        if not os.psth.isdir(path):
            contents = readFile(path)
            if contents in seenContents: return True
            seenContents.add(contents)
            return False
        else:
            for filename in os.listdir(path):
                solve(path+os.sep+filename)
                if result: return True
            return False

# Monte Carlo
import random 

def simulate():
    cut1 = random.random()
    cut2 = random.random()
    
    (small, big) = (min(cut1, cut2), max(cut1, cut2))

    side1 = small
    side2 = big - small
    side3 = 1 - big

    return (side3+side2+side1) > 2 * max(side1, side2, side3)


def stickyTriangle(trials):
    success = 0 
    for trail in range(trails):
        if (simulate):
            success += 1
    return success / trails


print(stickyTriangle(10000))















