__author__ = 'MarkMi'

import numpy as np

data = np.genfromtxt('recs2009_public.csv',delimiter=',', dtype="|S10")
puredata = np.delete(data,(0),axis =0)
totalElecUse = puredata[:,839].astype(np.float)
totalSqFt = puredata[:,827].astype(np.float)

index=[]
for i in xrange(len(puredata)):
    index.append(i)

def norm(list):
    lmin = min(list)
    lmax = max(list)
    newlist=[]
    for i in xrange(len(list)):
        temp = (list[i]-lmin)/(lmax-lmin)
        newlist.append(temp)

    return newlist

def calmatrix(index):
    Y = totalElecUse
    # x1 = puredata[:,26].astype(np.float).take(index)
    # x2 = puredata[:,30].astype(np.float).take(index)
    # x3 = puredata[:,31].astype(np.float).take(index)
    # x4 = puredata[:,34].astype(np.float).take(index)
    # x5 = puredata[:,225].astype(np.float).take(index)
    # x6 = puredata[:,227].astype(np.float).take(index)
    # x7 = puredata[:,235].astype(np.float).take(index)
    # x8 = puredata[:,236].astype(np.float).take(index)
    # x9 = puredata[:,314].astype(np.float).take(index)
    # x10 = puredata[:,461].astype(np.float).take(index)
    x11 = puredata[:,507].astype(np.float).take(index)
    x12 = puredata[:,534].astype(np.float).take(index)
    x13 = puredata[:,541].astype(np.float).take(index)
    x14 = puredata[:,542].astype(np.float).take(index)
    x15 = puredata[:,543].astype(np.float).take(index)
    x16 = puredata[:,547].astype(np.float).take(index)
    x17 = puredata[:,700].astype(np.float).take(index)
    x18 = puredata[:,702].astype(np.float).take(index)
    x19 = puredata[:,829].astype(np.float).take(index)
    x20 = puredata[:,831].astype(np.float).take(index)
    x21 = puredata[:,850].astype(np.float).take(index)

    Y = norm(Y)
    print 'mean of Y'
    print np.mean(Y)
    print 'trueY'
    print Y
    # X1= norm(x1)
    # X2 = norm(x2)
    # X3 = norm(x3)
    # X4 = norm(x4)
    # X5 = norm(x5)
    # X6 = norm(x6)
    # X7 = norm(x7)
    # X8 = norm(x8)
    # X9 = norm(x9)
    # X10 = norm(x10)
    X11 = norm(x11)
    X12 = norm(x12)
    X13 = norm(x13)
    X14 = norm(x14)
    X15 = norm(x15)
    X16 = norm(x16)
    X17 = norm(x17)
    X18 = norm(x18)
    X19 = norm(x19)
    X20 = norm(x20)
    X21 = norm(x21)

    thepat = []
    for i in xrange(len(Y)):
        part1=[]
        # part1+=[X1[i]]+[X2[i]]+[X3[i]]+[X4[i]]+[X5[i]]+[X6[i]]+[X7[i]]+[X8[i]]+[X9[i]]+[X10[i]]
        part1+=[X11[i]]+[X12[i]]+[X13[i]]+[X14[i]]+[X15[i]]+[X16[i]]+[X17[i]]+[X18[i]]+[X19[i]]+[X20[i]]+[X21[i]]
        part2 = [Y[i]]
        temp=[]
        temp.append(part1)
        temp.append(part2)
        thepat.append(temp)
    return thepat

thepat = calmatrix(index)
# Back-Propagation Neural Networks

import math
import random
import string

random.seed(0)

# calculate a random number where:  a <= rand < b
def rand(a, b):
    return (b-a)*random.random() + a

# Make a matrix (we could use NumPy to speed this up)
def makeMatrix(I, J, fill=0.0):
    m = []
    for i in range(I):
        m.append([fill]*J)
    return m

# our sigmoid function, tanh is a little nicer than the standard 1/(1+e^-x)
def sigmoid(x):
    return math.tanh(x)

# derivative of our sigmoid function, in terms of the output (i.e. y)
def dsigmoid(y):
    return 1.0 - y**2

class NN:
    def __init__(self, ni, nh, no):
        # number of input, hidden, and output nodes
        self.ni = ni + 1 # +1 for bias node
        self.nh = nh
        self.no = no

        # activations for nodes
        self.ai = [1.0]*self.ni
        self.ah = [1.0]*self.nh
        self.ao = [1.0]*self.no

        # create weights
        self.wi = makeMatrix(self.ni, self.nh)
        self.wo = makeMatrix(self.nh, self.no)
        # set them to random vaules
        for i in range(self.ni):
            for j in range(self.nh):
                self.wi[i][j] = rand(-0.2, 0.2)
        for j in range(self.nh):
            for k in range(self.no):
                self.wo[j][k] = rand(-2.0, 2.0)

        # last change in weights for momentum
        self.ci = makeMatrix(self.ni, self.nh)
        self.co = makeMatrix(self.nh, self.no)

    def update(self, inputs):
        if len(inputs) != self.ni-1:
            raise ValueError('wrong number of inputs')

        # input activations
        for i in range(self.ni-1):
            #self.ai[i] = sigmoid(inputs[i])
            self.ai[i] = inputs[i]

        # hidden activations
        for j in range(self.nh):
            sum = 0.0
            for i in range(self.ni):
                sum = sum + self.ai[i] * self.wi[i][j]
            self.ah[j] = sigmoid(sum)

        # output activations
        for k in range(self.no):
            sum = 0.0
            for j in range(self.nh):
                sum = sum + self.ah[j] * self.wo[j][k]
            self.ao[k] = sigmoid(sum)

        return self.ao[:]


    def backPropagate(self, targets, N, M):
        if len(targets) != self.no:
            raise ValueError('wrong number of target values')

        # calculate error terms for output
        output_deltas = [0.0] * self.no
        for k in range(self.no):
            error = targets[k]-self.ao[k]
            output_deltas[k] = dsigmoid(self.ao[k]) * error

        # calculate error terms for hidden
        hidden_deltas = [0.0] * self.nh
        for j in range(self.nh):
            error = 0.0
            for k in range(self.no):
                error = error + output_deltas[k]*self.wo[j][k]
            hidden_deltas[j] = dsigmoid(self.ah[j]) * error

        # update output weights
        for j in range(self.nh):
            for k in range(self.no):
                change = output_deltas[k]*self.ah[j]
                self.wo[j][k] = self.wo[j][k] + N*change + M*self.co[j][k]
                self.co[j][k] = change
                #print N*change, M*self.co[j][k]

        # update input weights
        for i in range(self.ni):
            for j in range(self.nh):
                change = hidden_deltas[j]*self.ai[i]
                self.wi[i][j] = self.wi[i][j] + N*change + M*self.ci[i][j]
                self.ci[i][j] = change

        # calculate error
        error = 0.0
        for k in range(len(targets)):
            error = error + (targets[k]-self.ao[k])**2
        return error


    def test(self, patterns):
        result=[]
        for p in patterns:
            result += self.update(p[0])
        print result

    def weights(self):
        print('Input weights:')
        for i in range(self.ni):
            print(self.wi[i])
        print()
        print('Output weights:')
        for j in range(self.nh):
            print(self.wo[j])

    def train(self, patterns, iterations=20, N=0.5, M=0.1):
        # N: learning rate
        # M: momentum factor
        for i in range(iterations):
            error = 0.0
            for p in patterns:
                inputs = p[0]
                targets = p[1]
                self.update(inputs)
                error = error + self.backPropagate(targets, N, M)
            if i % 10 == 0:
                print('error %-.5f' % error)


def demo():
    # Teach network XOR function
    pat = thepat

    # create a network with two input, two hidden, and one output nodes
    n = NN(11, 7, 1)
    # train it with some patterns
    n.train(pat)
    # test it
    n.test(pat)



if __name__ == '__main__':
    demo()
