import numpy as np
from minepy import MINE
data = np.genfromtxt('recs2009_public.csv',delimiter=',', dtype="|S10")
puredata = np.delete(data,(0),axis =0)
totalElecUse = puredata[:,839].astype(np.float)
totalSqFt = puredata[:,827].astype(np.float)
Y = np.divide(totalElecUse, totalSqFt)
for i in range(12,930):
    try:
        x = puredata[:,i].astype(np.float)
        mine = MINE(alpha=0.6, c=15)
        mine.compute_score(x, Y)
        print i, "MIC", mine.mic()
    except ValueError:
        continue